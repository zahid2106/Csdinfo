package com.csd.info

import com.csd.info.data.EmiPlan
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.ceil

fun Int.money(): String = "Rs " + NumberFormat.getIntegerInstance(Locale.US).format(this)

data class Estimate(val advance: Int, val months: Int, val monthly: Int, val total: Int, val remaining: Int)

object Emi {
    /** Default mark-ups taken from the median of the price list at 0% advance (12/24/36 months). */
    val defaultMarkup = mapOf(12 to 16.7, 24 to 32.0, 36 to 48.5)

    /** Mark-up % implied by the product's own 0%-advance plan, if it has one. */
    fun markupFrom(cash: Int, base: EmiPlan?, months: Int): Double =
        if (base != null && cash > 0) (base.total(months) - cash) * 100.0 / cash else defaultMarkup.getValue(months)

    /** ESTIMATE only: the financed balance carries the same mark-up as the 0%-advance plan. */
    fun estimate(cash: Int, advance: Int, months: Int, markupPct: Double): Estimate {
        val adv = advance.coerceIn(0, cash)
        val financed = (cash - adv) * (1 + markupPct / 100.0)
        val monthly = ceil(financed / months).toInt()
        return Estimate(adv, months, monthly, adv + monthly * months, monthly * months)
    }
}
