@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.csd.info.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.csd.info.MainViewModel
import com.csd.info.data.EmiPlan
import com.csd.info.data.Product
import com.csd.info.money

@Composable
fun SettingsScreen(vm: MainViewModel, nav: NavHostController) {
    val products by vm.products.collectAsStateWithLifecycle()
    AppScaffold("Settings", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            InfoCard {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Logo(56)
                    Column {
                        Text("CSD Info", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        Text("Version 1.0.0 · com.csd.info")
                    }
                }
                Text("${products.size} products from the supplied general price list (24 Feb 2024).")
                Text("Works fully offline. No login, no tracking, no ads, no permissions. Only the “Search on Google” button needs internet.")
            }
            OutlinedButton(onClick = { vm.clearHistory() }, Modifier.fillMaxWidth()) { Text("Clear search history") }
            Button(onClick = { nav.navigate("admin") }, Modifier.fillMaxWidth()) { Text("Admin area (PIN protected)") }
        }
    }
}

@Composable
fun AdminScreen(vm: MainViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val review by vm.review.collectAsStateWithLifecycle()
    var pin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf<String?>(null) } // "restore" | "reimport"
    var pendingRestore by remember { mutableStateOf<android.net.Uri?>(null) }
    val toast = { m: String -> Toast.makeText(ctx, m, Toast.LENGTH_LONG).show() }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportBackup(uri, toast)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { pendingRestore = uri; confirm = "restore" }
    }

    AppScaffold("Admin", { nav.popBackStack() }) { pad ->
        if (!vm.adminUnlocked) {
            Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Enter admin PIN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (vm.usingDefaultPin()) Text("First use: the default PIN is 1234. Change it after signing in.")
                OutlinedTextField(pin, { pin = it.filter(Char::isDigit) }, singleLine = true, label = { Text("PIN") },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                Button(onClick = { if (vm.pinOk(pin)) vm.adminUnlocked = true else toast("Wrong PIN") }) { Text("Unlock") }
            }
            return@AppScaffold
        }
        val results = remember(q, review) { if (q.isBlank()) emptyList() else vm.search(q, "", "", null, null, 20) }
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { SectionTitle("Data tools") }
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { nav.navigate("editor?id=0") }) { Text("Add product") }
                    OutlinedButton(onClick = { exportLauncher.launch("csd_info_backup.json") }) { Text("Export backup") }
                    OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/json", "*/*")) }) { Text("Restore backup") }
                    OutlinedButton(onClick = { confirm = "reimport" }) { Text("Reset to original catalogue") }
                }
            }
            item {
                Text("Original-PDF re-extraction runs on a computer with tools/build_catalog.py; copy the resulting catalog.tsv into the app project and rebuild (see README).",
                    style = MaterialTheme.typography.bodySmall)
            }
            item {
                OutlinedTextField(newPin, { newPin = it.filter(Char::isDigit) }, singleLine = true, label = { Text("New PIN (4+ digits)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth(),
                    trailingIcon = { TextButton(onClick = { if (newPin.length >= 4) { vm.setPin(newPin); newPin = ""; toast("PIN changed") } else toast("PIN too short") }) { Text("Save") } })
            }
            item { SectionTitle("Edit a product") }
            item { OutlinedTextField(q, { q = it }, singleLine = true, label = { Text("Search product to edit") }, modifier = Modifier.fillMaxWidth()) }
            items(results, key = { "s${it.id}" }) { p -> ProductCard(p) { nav.navigate("editor?id=${p.id}") } }
            item { SectionTitle("Flagged for manual review (${review.size})") }
            items(review, key = { "r${it.id}" }) { p ->
                Column {
                    Text("PDF page ${p.originalPdfPage}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFB26A00))
                    ProductCard(p) { nav.navigate("editor?id=${p.id}") }
                }
            }
        }
        if (confirm != null) {
            AlertDialog(
                onDismissRequest = { confirm = null },
                title = { Text("Replace all current data?") },
                text = { Text(if (confirm == "restore") "All current products, prices and your edits will be replaced by the backup file. Export a backup first if unsure."
                           else "All your edits and added products will be deleted and the original PDF catalogue restored.") },
                confirmButton = {
                    TextButton(onClick = {
                        val c = confirm; confirm = null
                        if (c == "restore") pendingRestore?.let { vm.restoreBackup(it, toast) } else vm.reimportBundled(toast)
                    }) { Text("Replace") }
                },
                dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
            )
        }
    }
}

private class PlanForm(
    var pct: String, var adv: String, var t12: String, var t24: String, var t36: String,
    var m12: String, var m24: String, var m36: String
)

@Composable
private fun Num(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) =
    OutlinedTextField(value, { onChange(it.filter { c -> c.isDigit() || c == '-' }) }, modifier, singleLine = true, label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))

@Composable
fun EditorScreen(vm: MainViewModel, nav: NavHostController, id: Long) {
    val ctx = LocalContext.current
    val toast = { m: String -> Toast.makeText(ctx, m, Toast.LENGTH_LONG).show() }
    var loaded by remember { mutableStateOf(id == 0L) }
    var original by remember { mutableStateOf<Product?>(null) }
    var name by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var specs by remember { mutableStateOf("") }
    var cash by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("0") }
    var plans by remember { mutableStateOf<List<PlanForm>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) } // forces recomposition after in-place plan edits
    var askDelete by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (id != 0L) {
            val p = vm.product(id)
            if (p != null) {
                original = p; name = p.productName; brand = p.brand; model = p.model; category = p.category
                specs = p.specifications; cash = p.cashPrice.toString(); page = p.originalPdfPage.toString()
                plans = vm.plans(id).map { PlanForm(it.advancePercent.toString(), it.advanceAmount.toString(), it.total12.toString(), it.total24.toString(),
                    it.total36.toString(), it.monthly12.toString(), it.monthly24.toString(), it.monthly36.toString()) }
            }
            loaded = true
        }
    }

    fun save() {
        val cashI = cash.toIntOrNull()
        if (name.isBlank() || cashI == null || cashI <= 0) { toast("Name and a valid cash price are required"); return }
        val list = ArrayList<EmiPlan>()
        for ((i, f) in plans.withIndex()) {
            val n = listOf(f.pct, f.adv, f.t12, f.t24, f.t36, f.m12, f.m24, f.m36).map { it.toIntOrNull() }
            if (n.any { it == null }) { toast("Plan ${i + 1} has an empty or invalid number"); return }
            list += EmiPlan(productId = 0, advancePercent = n[0]!!, advanceAmount = n[1]!!, total12 = n[2]!!, total24 = n[3]!!, total36 = n[4]!!,
                monthly12 = n[5]!!, monthly24 = n[6]!!, monthly36 = n[7]!!)
        }
        val base = original ?: com.csd.info.data.Product(productName = "", normalizedName = "", brand = "", model = "", category = "", cashPrice = 0, originalPdfPage = 0)
        val p = base.copy(
            productName = name.trim(), normalizedName = vm.normalized(name), brand = brand.trim().ifEmpty { "Other" }, model = model.trim(),
            category = category.trim().ifEmpty { "Other Products" }, specifications = specs.trim(), cashPrice = cashI,
            originalPdfPage = page.toIntOrNull() ?: 0, extractionStatus = if (id == 0L) "MANUAL" else "EDITED"
        )
        vm.saveProduct(p, list) { m -> toast(m); if (m == "Saved") nav.popBackStack() }
    }

    AppScaffold(if (id == 0L) "Add product" else "Edit product", { nav.popBackStack() }) { pad ->
        if (!vm.adminUnlocked) { Text("Admin only.", Modifier.padding(pad).padding(16.dp)); return@AppScaffold }
        if (!loaded) { Box(Modifier.padding(pad).padding(24.dp)) { CircularProgressIndicator() }; return@AppScaffold }
        val editTick = tick
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(if (editTick >= 0) 10.dp else 10.dp)) {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Product name") })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(brand, { brand = it }, Modifier.weight(1f), singleLine = true, label = { Text("Brand") })
                OutlinedTextField(model, { model = it }, Modifier.weight(1f), singleLine = true, label = { Text("Model") })
            }
            OutlinedTextField(category, { category = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Category") })
            OutlinedTextField(specs, { specs = it }, Modifier.fillMaxWidth(), label = { Text("Specifications") })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Num("Cash price", cash, { cash = it }, Modifier.weight(1f))
                Num("PDF page", page, { page = it }, Modifier.weight(1f))
            }
            SectionTitle("Instalment plans")
            plans.forEachIndexed { i, f ->
                InfoCard {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Num("Advance %", f.pct, { f.pct = it; tick++ }, Modifier.weight(1f))
                        Num("Advance Rs", f.adv, { f.adv = it; tick++ }, Modifier.weight(2f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Num("Total 12m", f.t12, { f.t12 = it; tick++ }, Modifier.weight(1f)); Num("Total 24m", f.t24, { f.t24 = it; tick++ }, Modifier.weight(1f)); Num("Total 36m", f.t36, { f.t36 = it; tick++ }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Num("Monthly 12", f.m12, { f.m12 = it; tick++ }, Modifier.weight(1f)); Num("Monthly 24", f.m24, { f.m24 = it; tick++ }, Modifier.weight(1f)); Num("Monthly 36", f.m36, { f.m36 = it; tick++ }, Modifier.weight(1f))
                    }
                    TextButton(onClick = { plans = plans.filterIndexed { j, _ -> j != i } }) { Text("Remove this plan") }
                }
            }
            OutlinedButton(onClick = { plans = plans + PlanForm("0", "0", "", "", "", "", "", "") }) { Text("Add plan") }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { save() }, Modifier.weight(1f)) { Text("Save") }
                if (id != 0L) OutlinedButton(onClick = { askDelete = true }, Modifier.weight(1f)) { Text("Delete") }
            }
        }
        if (askDelete) AlertDialog(
            onDismissRequest = { askDelete = false }, title = { Text("Delete this product?") },
            text = { Text("The product and all of its plans will be removed permanently.") },
            confirmButton = { TextButton(onClick = { askDelete = false; vm.deleteProduct(id) { m -> toast(m); nav.popBackStack() } }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Cancel") } }
        )
    }
}
