package com.csd.info.data

import android.content.Context
import androidx.room.withTransaction
import com.csd.info.search.SearchEngine
import com.csd.info.search.Text
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream

class ParsedProduct(val product: Product, val plans: List<EmiPlan>)

object CatalogParser {
    /** catalog.tsv: id, page, name, brand, model, category, review, cash, then 8 columns per plan. */
    fun parseTsv(input: InputStream): List<ParsedProduct> {
        val out = ArrayList<ParsedProduct>(3000)
        input.bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                if (line.isBlank()) continue
                val c = line.split('\t')
                if (c.size < 16) continue
                val name = c[2]
                val product = Product(
                    productName = name, normalizedName = Text.normalize(name),
                    brand = c[3], model = c[4], category = c[5],
                    cashPrice = c[7].toInt(), originalPdfPage = c[1].toInt(),
                    extractionStatus = if (c[6] == "1") "REVIEW" else "OK"
                )
                val plans = ArrayList<EmiPlan>()
                var i = 8
                while (i + 7 < c.size) {
                    plans += EmiPlan(
                        productId = 0, advancePercent = c[i].toInt(), advanceAmount = c[i + 1].toInt(),
                        total12 = c[i + 2].toInt(), total24 = c[i + 3].toInt(), total36 = c[i + 4].toInt(),
                        monthly12 = c[i + 5].toInt(), monthly24 = c[i + 6].toInt(), monthly36 = c[i + 7].toInt()
                    )
                    i += 8
                }
                out += ParsedProduct(product, plans)
            }
        }
        return out
    }
}

class Repository(private val ctx: Context) {
    val db = AppDb.get(ctx)
    val dao = db.dao()
    val engine = SearchEngine()

    suspend fun ensureImported() { if (dao.count() == 0) importBundled() }

    suspend fun importBundled() {
        val rows = ctx.assets.open("catalog.tsv").use { CatalogParser.parseTsv(it) }
        replaceAll(rows)
    }

    suspend fun replaceAll(rows: List<ParsedProduct>) = db.withTransaction {
        dao.clearProducts()
        for (chunk in rows.chunked(400)) {
            val ids = dao.insertProducts(chunk.map { it.product })
            val plans = ArrayList<EmiPlan>()
            chunk.forEachIndexed { i, r -> r.plans.forEach { plans += it.copy(id = 0, productId = ids[i]) } }
            dao.insertPlans(plans)
        }
    }

    suspend fun reloadIndex(): List<Product> {
        val list = dao.allProducts()
        engine.setProducts(list)
        return list
    }

    suspend fun saveProduct(p: Product, plans: List<EmiPlan>) = db.withTransaction {
        val id = if (p.id == 0L) dao.insertProduct(p) else { dao.updateProduct(p); dao.clearPlansFor(p.id); p.id }
        dao.insertPlans(plans.map { it.copy(id = 0, productId = id) })
    }

    suspend fun exportJson(): String {
        val plans = dao.allPlans().groupBy { it.productId }
        val arr = JSONArray()
        for (p in dao.allProducts()) {
            val o = JSONObject()
                .put("name", p.productName).put("brand", p.brand).put("model", p.model).put("category", p.category)
                .put("specifications", p.specifications).put("cash", p.cashPrice).put("page", p.originalPdfPage)
                .put("status", p.extractionStatus)
            val pa = JSONArray()
            for (pl in plans[p.id].orEmpty()) pa.put(
                JSONObject().put("pct", pl.advancePercent).put("adv", pl.advanceAmount)
                    .put("t12", pl.total12).put("t24", pl.total24).put("t36", pl.total36)
                    .put("m12", pl.monthly12).put("m24", pl.monthly24).put("m36", pl.monthly36)
            )
            arr.put(o.put("plans", pa))
        }
        return JSONObject().put("app", "CSD Info").put("version", 1).put("products", arr).toString()
    }

    fun parseJson(text: String): List<ParsedProduct> {
        val root = JSONObject(text)
        require(root.optString("app") == "CSD Info") { "Not a CSD Info backup file" }
        val arr = root.getJSONArray("products")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val name = o.getString("name")
            val prod = Product(
                productName = name, normalizedName = Text.normalize(name), brand = o.optString("brand"),
                model = o.optString("model"), category = o.optString("category"),
                specifications = o.optString("specifications"), cashPrice = o.getInt("cash"),
                originalPdfPage = o.optInt("page"), extractionStatus = o.optString("status", "OK")
            )
            val pa = o.getJSONArray("plans")
            val plans = (0 until pa.length()).map { j ->
                val q = pa.getJSONObject(j)
                EmiPlan(productId = 0, advancePercent = q.getInt("pct"), advanceAmount = q.getInt("adv"),
                    total12 = q.getInt("t12"), total24 = q.getInt("t24"), total36 = q.getInt("t36"),
                    monthly12 = q.getInt("m12"), monthly24 = q.getInt("m24"), monthly36 = q.getInt("m36"))
            }
            ParsedProduct(prod, plans)
        }
    }
}
