package com.csd.info.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Product::class, EmiPlan::class, SearchHistory::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): CatalogDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "csd_info.db")
                // Future schema changes: add .addMigrations(MIGRATION_1_2, ...) here. Never use destructive fallback,
                // because admins edit data on the device.
                .build().also { inst = it }
        }
    }
}
