package com.csd.info

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.csd.info.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CsdTheme { AppNav() } }
    }
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val vm: MainViewModel = viewModel()
    val str = { name: String -> navArgument(name) { type = NavType.StringType; defaultValue = "" } }
    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(vm, nav) }
        composable("results?q={q}&cat={cat}&brand={brand}", listOf(str("q"), str("cat"), str("brand"))) {
            ResultsScreen(vm, nav, it.arguments?.getString("q").orEmpty(), it.arguments?.getString("cat").orEmpty(), it.arguments?.getString("brand").orEmpty())
        }
        composable("product/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
            ProductScreen(vm, nav, it.arguments!!.getLong("id"))
        }
        composable("emi?productId={productId}", listOf(navArgument("productId") { type = NavType.LongType; defaultValue = -1L })) {
            EmiScreen(vm, nav, it.arguments!!.getLong("productId"))
        }
        composable("pdf?page={page}", listOf(navArgument("page") { type = NavType.IntType; defaultValue = 1 })) {
            PdfScreen(nav, it.arguments!!.getInt("page"))
        }
        composable("settings") { SettingsScreen(vm, nav) }
        composable("admin") { AdminScreen(vm, nav) }
        composable("editor?id={id}", listOf(navArgument("id") { type = NavType.LongType; defaultValue = 0L })) {
            EditorScreen(vm, nav, it.arguments!!.getLong("id"))
        }
    }
}

fun enc(s: String): String = Uri.encode(s)
