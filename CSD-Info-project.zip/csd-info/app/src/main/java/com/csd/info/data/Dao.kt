package com.csd.info.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CatalogDao {
    @Query("SELECT * FROM products") suspend fun allProducts(): List<Product>
    @Query("SELECT * FROM emi_plans") suspend fun allPlans(): List<EmiPlan>
    @Query("SELECT COUNT(*) FROM products") suspend fun count(): Int
    @Query("SELECT * FROM products WHERE id = :id") suspend fun product(id: Long): Product?
    @Query("SELECT * FROM emi_plans WHERE productId = :id ORDER BY advancePercent") suspend fun plans(id: Long): List<EmiPlan>

    @Insert suspend fun insertProduct(p: Product): Long
    @Insert suspend fun insertProducts(p: List<Product>): List<Long>
    @Insert suspend fun insertPlans(p: List<EmiPlan>)
    @Update suspend fun updateProduct(p: Product)

    @Query("DELETE FROM products WHERE id = :id") suspend fun deleteProduct(id: Long)
    @Query("DELETE FROM products") suspend fun clearProducts()
    @Query("DELETE FROM emi_plans WHERE productId = :id") suspend fun clearPlansFor(id: Long)

    @Query("SELECT * FROM products WHERE extractionStatus = 'REVIEW' ORDER BY originalPdfPage")
    fun reviewFlow(): Flow<List<Product>>

    @Query("UPDATE products SET viewCount = viewCount + 1, lastViewed = :ts WHERE id = :id")
    suspend fun markViewed(id: Long, ts: Long)
    @Query("SELECT * FROM products WHERE lastViewed > 0 ORDER BY lastViewed DESC LIMIT 10")
    fun recentFlow(): Flow<List<Product>>
    @Query("SELECT * FROM products WHERE viewCount > 0 ORDER BY viewCount DESC, lastViewed DESC LIMIT 10")
    fun popularFlow(): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveSearch(h: SearchHistory)
    @Query("SELECT * FROM search_history ORDER BY ts DESC LIMIT 12") fun historyFlow(): Flow<List<SearchHistory>>
    @Query("DELETE FROM search_history") suspend fun clearHistory()
    @Query("DELETE FROM search_history WHERE term = :t") suspend fun deleteHistory(t: String)
}
