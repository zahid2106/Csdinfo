package com.csd.info.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** One catalogue item. Values come straight from the price-list PDF (never invented). */
@Entity(tableName = "products", indices = [Index("category"), Index("brand")])
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productName: String,
    val normalizedName: String,
    val brand: String,
    val model: String,
    val category: String,
    /** The price list has no specification column, so this stays empty unless an admin adds text. */
    val specifications: String = "",
    val cashPrice: Int,
    val originalPdfPage: Int,
    /** OK = extracted cleanly, REVIEW = needs manual check, EDITED = corrected by admin, MANUAL = added by admin. */
    val extractionStatus: String = "OK",
    val viewCount: Int = 0,
    val lastViewed: Long = 0
)

/** One instalment plan row (one advance level) of a product. Totals include the advance. */
@Entity(
    tableName = "emi_plans",
    foreignKeys = [ForeignKey(Product::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("productId")]
)
data class EmiPlan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    /** Advance level printed in the list (0,10,..50); -1 when it could not be identified. */
    val advancePercent: Int,
    val advanceAmount: Int,
    val total12: Int, val total24: Int, val total36: Int,
    val monthly12: Int, val monthly24: Int, val monthly36: Int
) {
    fun total(months: Int) = when (months) { 12 -> total12; 24 -> total24; else -> total36 }
    fun monthly(months: Int) = when (months) { 12 -> monthly12; 24 -> monthly24; else -> monthly36 }
}

@Entity(tableName = "search_history")
data class SearchHistory(@PrimaryKey val term: String, val ts: Long)
