@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.csd.info.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.csd.info.MainViewModel
import com.csd.info.enc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun HomeScreen(vm: MainViewModel, nav: NavHostController) {
    val ready by vm.ready.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val products by vm.products.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val popular by vm.popular.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()

    var q by rememberSaveable { mutableStateOf("") }
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }
    LaunchedEffect(q, ready) {
        if (ready && q.trim().length >= 2) {
            delay(120)
            suggestions = withContext(Dispatchers.Default) { vm.repo.engine.search(q, 6).map { it.productName } }
        } else suggestions = emptyList()
    }
    fun go(text: String) { vm.saveSearch(text); nav.navigate("results?q=${enc(text)}") }

    val categories = remember(products) { products.groupingBy { it.category }.eachCount().toList().sortedByDescending { it.second } }

    AppScaffold("CSD Info", null, actions = {
        IconButton(onClick = { nav.navigate("settings") }) { Icon(Icons.Default.Settings, "Settings") }
    }) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Logo(64)
                    Column {
                        Text("CSD Info", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                        Text("Offline product & instalment catalogue", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    shape = RoundedCornerShape(28.dp), placeholder = { Text("Search e.g. Samsung 256GB, Haier 1.5 Ton") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = { if (q.isNotEmpty()) IconButton(onClick = { q = "" }) { Icon(Icons.Default.Clear, "Clear") } },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { if (q.isNotBlank()) go(q) })
                )
            }
            if (!ready) {
                item {
                    if (error != null) InfoCard {
                        Text("Could not load the catalogue", fontWeight = FontWeight.Bold)
                        Text(error ?: "")
                        Button(onClick = { vm.load() }) { Text("Try again") }
                    } else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(28.dp)); Spacer(Modifier.width(12.dp))
                        Text("Preparing catalogue (first launch only)…")
                    }
                }
            } else {
                if (q.isBlank() && history.isNotEmpty()) item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            SectionTitle("Recent searches")
                            TextButton(onClick = { vm.clearHistory() }) { Text("Clear history") }
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            history.forEach { h -> SuggestionChip(onClick = { go(h.term) }, label = { Text(h.term) }) }
                        }
                    }
                }
                if (q.isNotBlank() && suggestions.isNotEmpty()) item {
                    InfoCard {
                        suggestions.forEach { s ->
                            Text(s, Modifier.fillMaxWidth().clickable { q = s; go(s) }.padding(vertical = 8.dp), maxLines = 2)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        InfoCard(Modifier.weight(1f), MaterialTheme.colorScheme.primaryContainer) {
                            Text("${products.size}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                            Text("products")
                        }
                        InfoCard(Modifier.weight(1f), MaterialTheme.colorScheme.primaryContainer) {
                            Text("${categories.size}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                            Text("categories")
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { nav.navigate("emi?productId=-1") }, Modifier.weight(1f)) { Text("Quick EMI") }
                        OutlinedButton(onClick = { nav.navigate("pdf?page=1") }, Modifier.weight(1f)) { Text("View original PDF") }
                    }
                }
                item { SectionTitle("Categories") }
                items(categories.chunked(2)) { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (name, n) ->
                            Card(
                                Modifier.weight(1f).clickable { nav.navigate("results?cat=${enc(name)}") }, shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(Modifier.padding(14.dp)) {
                                    Text(name, fontWeight = FontWeight.SemiBold, maxLines = 2)
                                    Text("$n items", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                if (popular.isNotEmpty()) {
                    item { SectionTitle("Popular products") }
                    items(popular.take(5), key = { "pop${it.id}" }) { p -> ProductCard(p) { nav.navigate("product/${p.id}") } }
                }
                if (recent.isNotEmpty()) {
                    item { SectionTitle("Recently viewed") }
                    items(recent.take(5), key = { "rec${it.id}" }) { p -> ProductCard(p) { nav.navigate("product/${p.id}") } }
                }
            }
        }
    }
}
