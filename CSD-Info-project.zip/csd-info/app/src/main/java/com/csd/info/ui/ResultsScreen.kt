@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.csd.info.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.csd.info.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ResultsScreen(vm: MainViewModel, nav: NavHostController, q0: String, cat0: String, brand0: String) {
    val products by vm.products.collectAsStateWithLifecycle()
    var q by rememberSaveable { mutableStateOf(q0) }
    var cat by rememberSaveable { mutableStateOf(cat0) }
    var brand by rememberSaveable { mutableStateOf(brand0) }
    var minP by rememberSaveable { mutableStateOf("") }
    var maxP by rememberSaveable { mutableStateOf("") }
    var filters by rememberSaveable { mutableStateOf(cat0.isNotEmpty() || brand0.isNotEmpty()) }

    val cats = remember(products) { products.map { it.category }.distinct().sorted() }
    val brands = remember(products) { products.map { it.brand }.distinct().sorted() }

    val results by produceState<List<com.csd.info.data.Product>?>(null, q, cat, brand, minP, maxP, products) {
        value = null
        value = withContext(Dispatchers.Default) { vm.search(q, cat, brand, minP.toIntOrNull(), maxP.toIntOrNull()) }
    }

    AppScaffold("Search results", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(28.dp), placeholder = { Text("Search products") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = { if (q.isNotEmpty()) IconButton(onClick = { q = "" }) { Icon(Icons.Default.Clear, "Clear") } },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.saveSearch(q) })
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(results?.let { "${it.size} result(s)" + if (it.size >= 300) " (first 300)" else "" } ?: "Searching…", fontWeight = FontWeight.Medium)
                TextButton(onClick = { filters = !filters }) { Text(if (filters) "Hide filters" else "Filters") }
            }
            if (filters) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DropdownField("Category", cats, cat, { cat = it }, Modifier.weight(1f))
                        DropdownField("Brand", brands, brand, { brand = it }, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(minP, { minP = it.filter(Char::isDigit) }, Modifier.weight(1f), singleLine = true, label = { Text("Min price") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        OutlinedTextField(maxP, { maxP = it.filter(Char::isDigit) }, Modifier.weight(1f), singleLine = true, label = { Text("Max price") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    }
                }
            }
            val list = results
            when {
                list == null -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                list.isEmpty() -> Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No products found", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Check the spelling, remove a word, or clear the filters.")
                }
                else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                    items(list, key = { it.id }) { p -> ProductCard(p) { nav.navigate("product/${p.id}") } }
                }
            }
        }
    }
}
