@file:OptIn(ExperimentalMaterial3Api::class)

package com.csd.info.ui

import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PdfScreen(nav: NavHostController, startPage: Int) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val screenW = ctx.resources.displayMetrics.widthPixels
    val mutex = remember { Mutex() }
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var pfd by remember { mutableStateOf<ParcelFileDescriptor?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var pages by remember { mutableIntStateOf(0) }
    var page by rememberSaveable { mutableIntStateOf((startPage - 1).coerceAtLeast(0)) }
    var zoom by rememberSaveable { mutableFloatStateOf(1f) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var jump by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        try {
            withContext(Dispatchers.IO) {
                val f = File(ctx.filesDir, "csd_pricelist.pdf")
                if (!f.exists() || f.length() == 0L) {
                    ctx.assets.open("csd_pricelist.pdf").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                }
                val d = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = PdfRenderer(d)
                pfd = d; renderer = r; pages = r.pageCount
            }
            page = page.coerceIn(0, (pages - 1).coerceAtLeast(0))
        } catch (e: Throwable) { error = e.message ?: e.toString() }
    }
    DisposableEffect(Unit) { onDispose { try { renderer?.close(); pfd?.close() } catch (_: Throwable) {} } }

    LaunchedEffect(renderer, page, zoom) {
        val r = renderer ?: return@LaunchedEffect
        val w = (screenW * zoom).toInt().coerceAtLeast(200)
        val out = withContext(Dispatchers.IO) {
            mutex.withLock {
                val pg = r.openPage(page.coerceIn(0, r.pageCount - 1))
                try {
                    val h = (w.toLong() * pg.height / pg.width).toInt()
                    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    b.eraseColor(AColor.WHITE)
                    pg.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    b
                } finally { pg.close() }
            }
        }
        bmp = out
    }

    AppScaffold("Original price list", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (error != null) { Text("Cannot open PDF: $error", Modifier.padding(16.dp)); return@Column }
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { if (page > 0) page-- }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("‹") }
                Text("${page + 1} / $pages")
                OutlinedButton(onClick = { if (page < pages - 1) page++ }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("›") }
                OutlinedTextField(jump, { jump = it.filter(Char::isDigit) }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Go to page") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { jump.toIntOrNull()?.let { page = (it - 1).coerceIn(0, (pages - 1).coerceAtLeast(0)) } }))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { zoom = (zoom - 0.5f).coerceAtLeast(1f) }) { Text("Zoom −") }
                Text("${(zoom * 100).toInt()}%")
                OutlinedButton(onClick = { zoom = (zoom + 0.5f).coerceAtMost(3f) }) { Text("Zoom +") }
            }
            Box(Modifier.weight(1f).fillMaxWidth().horizontalScroll(rememberScrollState()).verticalScroll(rememberScrollState())) {
                val b = bmp
                if (b == null) CircularProgressIndicator(Modifier.padding(24.dp))
                else Image(b.asImageBitmap(), "PDF page ${page + 1}", Modifier.width(with(density) { b.width.toDp() }), contentScale = ContentScale.FillWidth)
            }
        }
    }
}
