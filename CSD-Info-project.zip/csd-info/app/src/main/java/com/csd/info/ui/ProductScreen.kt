@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.csd.info.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.csd.info.MainViewModel
import com.csd.info.data.EmiPlan
import com.csd.info.data.Product
import com.csd.info.money

@Composable
fun ProductScreen(vm: MainViewModel, nav: NavHostController, id: Long) {
    val ctx = LocalContext.current
    var product by remember { mutableStateOf<Product?>(null) }
    var plans by remember { mutableStateOf<List<EmiPlan>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var sel by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(id) {
        product = vm.product(id); plans = vm.plans(id); loaded = true
        if (product != null) vm.markViewed(id)
    }

    AppScaffold("Product details", { nav.popBackStack() }) { pad ->
        val p = product
        if (p == null) {
            Box(Modifier.padding(pad).fillMaxSize().padding(24.dp)) { if (loaded) Text("This product no longer exists.") else CircularProgressIndicator() }
            return@AppScaffold
        }
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                InfoCard {
                    Text(p.productName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    KeyValue("Brand", p.brand)
                    KeyValue("Model", p.model.ifEmpty { "Not identified" })
                    KeyValue("Category", p.category)
                    KeyValue("PDF page", p.originalPdfPage.toString())
                    Text("Specifications", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Text(p.specifications.ifEmpty { "Not provided in the price list." })
                    if (p.extractionStatus == "REVIEW") Text(
                        "⚠ This record was flagged during extraction. Compare with the original PDF page.", color = Color(0xFFB26A00)
                    )
                }
            }
            item {
                InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                    Text("CASH PRICE", style = MaterialTheme.typography.labelLarge)
                    Text(p.cashPrice.money(), fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("Price if paid in full – not an instalment total.", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (plans.isEmpty()) item { InfoCard { Text("No instalment plan is listed for this product.") } } else {
                item { SectionTitle("Instalment plans (from the price list)") }
                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        plans.forEachIndexed { i, pl ->
                            FilterChip(selected = sel == i, onClick = { sel = i },
                                label = { Text(if (pl.advancePercent >= 0) "${pl.advancePercent}% advance" else "Plan ${i + 1}") })
                        }
                    }
                }
                val pl = plans[sel.coerceIn(0, plans.lastIndex)]
                item {
                    InfoCard {
                        Text("ADVANCE PAYMENT", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        Text(pl.advanceAmount.money(), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        if (pl.advancePercent < 0) Text("Advance level could not be identified – check the PDF.", color = Color(0xFFB26A00))
                    }
                }
                items3(pl)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { nav.navigate("emi?productId=${p.id}") }, Modifier.weight(1f)) { Text("Calculate EMI") }
                    Button(onClick = {
                        val url = "https://www.google.com/search?q=" + Uri.encode(p.productName)
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                        catch (e: Exception) { Toast.makeText(ctx, "No browser found", Toast.LENGTH_SHORT).show() }
                    }, Modifier.weight(1f)) { Text("Search on Google") }
                }
            }
            item {
                OutlinedButton(onClick = { nav.navigate("pdf?page=${p.originalPdfPage}") }, Modifier.fillMaxWidth()) { Text("View page ${p.originalPdfPage} in original PDF") }
            }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.items3(pl: EmiPlan) {
    listOf(12, 24, 36).forEach { m ->
        item {
            InfoCard {
                Text("$m MONTHS", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                KeyValue("Monthly installment", pl.monthly(m).money(), bold = true)
                KeyValue("Total payable (incl. advance)", pl.total(m).money())
                KeyValue("Remaining balance", (pl.total(m) - pl.advanceAmount).money())
            }
        }
    }
}
