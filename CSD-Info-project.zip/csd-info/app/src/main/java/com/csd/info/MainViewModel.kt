package com.csd.info

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.csd.info.data.*
import com.csd.info.search.Text
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val repo = Repository(app)
    private val prefs = app.getSharedPreferences("csd_prefs", Context.MODE_PRIVATE)

    val ready = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val products = MutableStateFlow<List<Product>>(emptyList())
    val recent = repo.dao.recentFlow().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val popular = repo.dao.popularFlow().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val history = repo.dao.historyFlow().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val review = repo.dao.reviewFlow().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    var adminUnlocked by mutableStateOf(false)

    init { load() }

    fun load() {
        viewModelScope.launch(Dispatchers.IO) {
            error.value = null
            try {
                repo.ensureImported()
                products.value = repo.reloadIndex()
                ready.value = true
            } catch (e: Throwable) { error.value = e.message ?: e.toString() }
        }
    }

    suspend fun product(id: Long) = withContext(Dispatchers.IO) { repo.dao.product(id) }
    suspend fun plans(id: Long) = withContext(Dispatchers.IO) { repo.dao.plans(id) }

    fun search(q: String, cat: String, brand: String, min: Int?, max: Int?, limit: Int = 300): List<Product> =
        repo.engine.search(q, limit) { p ->
            (cat.isEmpty() || p.category == cat) && (brand.isEmpty() || p.brand == brand) &&
                (min == null || p.cashPrice >= min) && (max == null || p.cashPrice <= max)
        }

    fun saveSearch(q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) { repo.dao.saveSearch(SearchHistory(t, System.currentTimeMillis())) }
    }
    fun clearHistory() { viewModelScope.launch(Dispatchers.IO) { repo.dao.clearHistory() } }
    fun markViewed(id: Long) { viewModelScope.launch(Dispatchers.IO) { repo.dao.markViewed(id, System.currentTimeMillis()) } }

    // ---- admin ----
    private fun hash(pin: String) = MessageDigest.getInstance("SHA-256").digest(("csd-info:$pin").toByteArray())
        .joinToString("") { "%02x".format(it) }
    fun pinOk(pin: String): Boolean = hash(pin) == (prefs.getString("pin", null) ?: hash("1234"))
    fun setPin(pin: String) { prefs.edit().putString("pin", hash(pin)).apply() }
    fun usingDefaultPin() = prefs.getString("pin", null) == null

    private fun run(done: (String) -> Unit, block: suspend () -> String) {
        viewModelScope.launch(Dispatchers.IO) {
            val msg = try { block() } catch (e: Throwable) { "Failed: ${e.message ?: e}" }
            withContext(Dispatchers.Main) { done(msg) }
        }
    }

    fun saveProduct(p: Product, plans: List<EmiPlan>, done: (String) -> Unit) = run(done) {
        repo.saveProduct(p, plans); products.value = repo.reloadIndex(); "Saved"
    }
    fun deleteProduct(id: Long, done: (String) -> Unit) = run(done) {
        repo.dao.deleteProduct(id); products.value = repo.reloadIndex(); "Deleted"
    }
    fun exportBackup(uri: Uri, done: (String) -> Unit) = run(done) {
        val json = repo.exportJson()
        getApplication<Application>().contentResolver.openOutputStream(uri, "wt")!!.use { it.write(json.toByteArray()) }
        "Backup saved"
    }
    fun restoreBackup(uri: Uri, done: (String) -> Unit) = run(done) {
        val text = getApplication<Application>().contentResolver.openInputStream(uri)!!.use { it.readBytes().decodeToString() }
        val rows = repo.parseJson(text)
        repo.replaceAll(rows); products.value = repo.reloadIndex(); "Restored ${rows.size} products"
    }
    fun reimportBundled(done: (String) -> Unit) = run(done) {
        repo.importBundled(); products.value = repo.reloadIndex(); "Original catalogue restored"
    }
    fun normalized(s: String) = Text.normalize(s)
}
