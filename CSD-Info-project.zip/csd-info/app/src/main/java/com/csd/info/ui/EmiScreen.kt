@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.csd.info.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.csd.info.Emi
import com.csd.info.MainViewModel
import com.csd.info.data.EmiPlan
import com.csd.info.data.Product
import com.csd.info.money

@Composable
fun EmiScreen(vm: MainViewModel, nav: NavHostController, productId: Long) {
    var product by remember { mutableStateOf<Product?>(null) }
    var plans by remember { mutableStateOf<List<EmiPlan>>(emptyList()) }
    var priceText by rememberSaveable { mutableStateOf("") }
    var advText by rememberSaveable { mutableStateOf("0") }
    var months by rememberSaveable { mutableIntStateOf(12) }

    LaunchedEffect(productId) {
        if (productId > 0) {
            product = vm.product(productId); plans = vm.plans(productId)
            if (priceText.isEmpty()) priceText = product?.cashPrice?.toString().orEmpty()
        }
    }

    val price = priceText.toIntOrNull() ?: 0
    val adv = (advText.toIntOrNull() ?: 0).coerceAtMost(price)
    val base = plans.firstOrNull { it.advancePercent == 0 }
    val pdfPlan: EmiPlan? = product?.let { p -> if (price == p.cashPrice) plans.firstOrNull { it.advanceAmount == adv } else null }

    fun est(m: Int) = Emi.estimate(price, adv, m, Emi.markupFrom(price, if (product != null) base else null, m))

    AppScaffold("EMI calculator", { nav.popBackStack() }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            product?.let { Text(it.productName, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            OutlinedTextField(priceText, { priceText = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Cash price (Rs)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(advText, { advText = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("Advance payment (Rs)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            if (plans.isNotEmpty() && product != null) {
                Text("Advance levels in the price list", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    plans.forEach { pl ->
                        AssistChip(onClick = { priceText = product!!.cashPrice.toString(); advText = pl.advanceAmount.toString() },
                            label = { Text(if (pl.advancePercent >= 0) "${pl.advancePercent}% · ${pl.advanceAmount.money()}" else pl.advanceAmount.money()) })
                    }
                }
            }
            Text("Duration", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(12, 24, 36).forEach { m -> FilterChip(selected = months == m, onClick = { months = m }, label = { Text("$m months") }) }
            }

            if (price <= 0) {
                Text("Enter a cash price to see results.")
            } else {
                if (pdfPlan != null) {
                    InfoCard(container = MaterialTheme.colorScheme.primaryContainer) {
                        Text("ORIGINAL PRICE-LIST FIGURES", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                        KeyValue("Advance payment", pdfPlan.advanceAmount.money())
                        KeyValue("Monthly installment", pdfPlan.monthly(months).money(), true)
                        KeyValue("Remaining balance", (pdfPlan.total(months) - pdfPlan.advanceAmount).money())
                        KeyValue("Total payable", pdfPlan.total(months).money(), true)
                    }
                }
                val e = est(months)
                InfoCard(container = if (pdfPlan == null) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface) {
                    Text("CALCULATED ESTIMATE (not a price-list figure)", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    KeyValue("Advance payment", e.advance.money())
                    KeyValue("Monthly installment", e.monthly.money(), true)
                    KeyValue("Remaining balance", e.remaining.money())
                    KeyValue("Total payable", e.total.money(), true)
                    Text(
                        if (product != null && base != null) "Uses the mark-up of this product's 0%-advance plan. Actual dealer figures may differ slightly."
                        else "Uses typical price-list mark-ups (12m ≈ 16.7%, 24m ≈ 32%, 36m ≈ 48.5%). Actual figures may differ.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                SectionTitle("Compare durations")
                InfoCard {
                    listOf(12, 24, 36).forEach { m ->
                        val src = pdfPlan
                        val monthly = src?.monthly(m) ?: est(m).monthly
                        val total = src?.total(m) ?: est(m).total
                        KeyValue("$m months  ·  ${if (src != null) "list" else "estimate"}", "${monthly.money()} / mo  (${total.money()})")
                    }
                }
            }
        }
    }
}

