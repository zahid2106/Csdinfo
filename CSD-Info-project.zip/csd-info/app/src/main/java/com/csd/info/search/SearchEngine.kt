package com.csd.info.search

import com.csd.info.data.Product
import kotlin.math.abs

object Text {
    /** Lower-case, strip punctuation (keeping decimals such as 1.5), collapse spaces. */
    fun normalize(s: String): String {
        val l = s.lowercase().replace("&amp;", "&")
        val sb = StringBuilder(l.length)
        for (i in l.indices) {
            val c = l[i]
            when {
                c.isLetterOrDigit() -> sb.append(c)
                c == '.' && i > 0 && i < l.lastIndex && l[i - 1].isDigit() && l[i + 1].isDigit() -> sb.append('.')
                else -> sb.append(' ')
            }
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }

    fun levenshtein(a: String, b: String, max: Int): Int {
        if (abs(a.length - b.length) > max) return max + 1
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (cur[j] < rowMin) rowMin = cur[j]
            }
            if (rowMin > max) return max + 1
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }
}

/**
 * Offline search over the in-memory catalogue (a few thousand rows, so a scan is instant).
 * Every query word must match the SAME product (AND semantics).
 * Ranking: 0 exact name, 1 exact model, 2 all words exact/prefix, 3 partial, 4 spelling-tolerant.
 */
class SearchEngine {
    private class Indexed(val p: Product, val norm: String, val tokens: List<String>, val compact: String, val model: String)

    @Volatile private var items: List<Indexed> = emptyList()

    fun setProducts(list: List<Product>) {
        items = list.map {
            val n = it.normalizedName.ifEmpty { Text.normalize(it.productName) }
            Indexed(it, n, n.split(' '), n.replace(" ", ""), Text.normalize(it.model).replace(" ", ""))
        }
    }

    /** cost: 0 exact, 1 prefix, 2 contains, 3+d fuzzy (d edits); -1 no match */
    private fun tokenCost(q: String, toks: List<String>): Int {
        var best = -1
        val hasDigit = q.any { it.isDigit() }
        val maxD = when { hasDigit -> 0; q.length <= 3 -> 0; q.length <= 6 -> 1; else -> 2 }
        for (t in toks) {
            val c = when {
                t == q -> 0
                t.startsWith(q) -> 1
                q.length >= 2 && t.contains(q) -> 2
                maxD > 0 && q.length >= 4 -> {
                    var d = Text.levenshtein(q, t, maxD)
                    // also tolerate typos in a still-being-typed word
                    if (d > maxD && t.length > q.length) d = Text.levenshtein(q, t.substring(0, q.length), maxD)
                    if (d <= maxD) 3 + d else -1
                }
                else -> -1
            }
            if (c == 0) return 0
            if (c >= 0 && (best == -1 || c < best)) best = c
        }
        return best
    }

    fun search(query: String, limit: Int = 300, filter: (Product) -> Boolean = { true }): List<Product> {
        val nq = Text.normalize(query)
        val data = items
        if (nq.isEmpty()) return data.asSequence().map { it.p }.filter(filter).sortedBy { it.productName }.take(limit).toList()
        val qTokens = nq.split(' ')
        val qCompact = nq.replace(" ", "")
        class Hit(val p: Product, val tier: Int, val cost: Int, val len: Int)
        val hits = ArrayList<Hit>()
        for (it in data) {
            if (!filter(it.p)) continue
            if (it.norm == nq) { hits += Hit(it.p, 0, 0, it.norm.length); continue }
            if (it.model.isNotEmpty() && it.model == qCompact) { hits += Hit(it.p, 1, 0, it.norm.length); continue }
            var sum = 0; var worst = 0; var ok = true
            for (qt in qTokens) {
                val c = tokenCost(qt, it.tokens)
                if (c < 0) { ok = false; break }
                sum += c; if (c > worst) worst = c
            }
            if (ok) {
                val tier = when { worst <= 1 -> 2; worst == 2 -> 3; else -> 4 }
                hits += Hit(it.p, tier, sum, it.norm.length)
            } else if (qCompact.length >= 4 && it.compact.contains(qCompact)) {
                hits += Hit(it.p, 3, 2, it.norm.length) // "gs12fith1w" style input with other spacing
            }
        }
        return hits.sortedWith(compareBy({ it.tier }, { it.cost }, { it.len })).take(limit).map { it.p }
    }
}
