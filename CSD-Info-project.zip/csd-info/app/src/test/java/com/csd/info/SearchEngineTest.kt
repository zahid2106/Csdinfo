package com.csd.info

import com.csd.info.data.Product
import com.csd.info.search.SearchEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchEngineTest {
    private fun p(id: Long, name: String, model: String = "") =
        Product(id, name, com.csd.info.search.Text.normalize(name), "", model, "", cashPrice = 1000, originalPdfPage = 1)

    private val engine = SearchEngine().apply {
        setProducts(listOf(
            p(1, "SAMSUNG GALAXY A56 256GB", "A56"),
            p(2, "SAMSUNG GALAXY A24 128GB", "A24"),
            p(3, "HAIER SPLIT AC HSU-18HFM 1.5 TON", "HSU-18HFM"),
            p(4, "DAWLANCE REFRIGERATOR 9170", "9170")
        ))
    }

    @Test fun typosStillFind() {
        for (q in listOf("samsng", "samsun", "samung", "galaxi", "galxy")) assertTrue(q, engine.search(q).any { it.id == 1L })
    }
    @Test fun allWordsMustMatchSameProduct() {
        val r = engine.search("samsung 256gb")
        assertEquals(listOf(1L), r.map { it.id })
    }
    @Test fun decimalsAndModels() {
        assertEquals(3L, engine.search("haier 1.5 ton").first().id)
        assertEquals(3L, engine.search("hsu18hfm").first().id)
    }
    @Test fun unrelatedWordDoesNotLeak() {
        assertTrue(engine.search("samsung refrigerator").isEmpty())
    }
}
