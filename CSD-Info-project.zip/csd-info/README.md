# CSD Info

Offline Android catalogue (Kotlin, Jetpack Compose, Material 3, Room, MVVM) built from the supplied
**General Price List (22 Feb 2024, 339 pages)**: 2,598 products, each with cash price and the
advance / 12-24-36 month instalment table exactly as printed in the PDF.

* Package: `com.csd.info`, minSdk 26 (Android 8.0), targetSdk 35
* No permissions, no login, no ads, no tracking. Only **Search on Google** uses the internet.

## Get the APK from GitHub (no Android Studio needed)
1. Create a new GitHub repository and upload / push this whole folder.
2. Open the **Actions** tab → **Build APK** → wait for the green tick (about 5–8 minutes).
3. Open the finished run → **Artifacts** → download `CSD-Info-debug-apk` (and `CSD-Info-release-apk`).
4. Unzip, copy the `.apk` to the phone, tap it and allow “install unknown apps” once.

The release APK is signed with the debug key so it installs for testing; use your own keystore for the Play Store.

## Build locally
Open the folder in Android Studio (Koala or newer, JDK 17) and press Run, or `gradle assembleDebug`.

## How data gets into the app
`app/src/main/assets/catalog.tsv` is generated from the PDF by `tools/build_catalog.py`
(`pip install pdfplumber`). On first launch the app imports it into Room (about 1 second); after that the PDF is
never parsed again. The original PDF is bundled as `assets/csd_pricelist.pdf` and shown in the in-app viewer
(Android `PdfRenderer`: page navigation, zoom, go-to-page; text search inside the PDF is not provided by Android,
use the catalogue search instead).

To use a new price list: `python tools/build_catalog.py new.pdf app/src/main/assets/catalog.tsv`, replace
`csd_pricelist.pdf`, commit, let GitHub build. Users can then use Admin → *Reset to original catalogue*
(this deliberately asks for confirmation because it replaces local edits).

## Data notes
* PDF columns: Item name, advance %, price, advance amount, total (12/24/36 months), monthly (12/24/36 months).
* Brand, category and model are **derived from the item name** by keyword rules (the PDF has no such columns).
* The PDF has no specifications; that field is empty unless an admin adds text.
* 72 products are flagged `REVIEW` (fewer than six advance levels, or name text that overlapped the numbers in the PDF).
  They appear in Admin → *Flagged for manual review* and are marked in the product page.
* The PDF is a text PDF, so OCR is not needed for it; OCR for scanned PDFs is not included in the app.

## Search
Offline, in-memory over the catalogue: normalisation, tokens, prefix/partial match, Levenshtein fuzzy match,
all words must match the same product, ranking exact name → exact model → all words → partial → fuzzy.
(SQLite FTS5 is not exposed by Room, and a scan of ~2.6k rows is instant, so it is not used.)

## Admin
Settings → Admin area. Default PIN **1234** (change it on first use). Add / edit / delete products and plans,
review flagged items, export / restore a JSON backup, reset to the original catalogue. This is an on-device
convenience lock, not strong security.

## Tests
`gradle testDebugUnitTest` runs the search-engine tests (typos, multi-word, decimals, model codes).
