#!/usr/bin/env python3
"""Rebuild app/src/main/assets/catalog.tsv from the price-list PDF.
Usage: pip install pdfplumber; python tools/build_catalog.py price.pdf app/src/main/assets/catalog.tsv
"""
import sys, re, html, collections
import pdfplumber
NUM = re.compile(r'^\d+$')

def read_rows(pdf_path):
    out = []
    with pdfplumber.open(pdf_path) as pdf:
        for pn, page in enumerate(pdf.pages, 1):
            ws = page.extract_words(x_tolerance=1.5, y_tolerance=2)
            anchors = sorted([w for w in ws if 285 <= w['x0'] <= 325 and NUM.match(w['text']) and len(w['text']) >= 4], key=lambda w: w['top'])
            for a in anchors:
                y = a['top']
                rw = sorted([w for w in ws if abs(w['top'] - y) < 4 and w['x0'] >= 268], key=lambda w: w['x0'])
                v = [int(w['text']) for w in rw if NUM.match(w['text'])]
                name = ' '.join(w['text'] for w in sorted([w for w in ws if w['x0'] < 268 and abs(w['top'] - y) < 4], key=lambda w: w['x0']))
                if len(v) == 9: v = v[1:]
                elif len(v) != 8: continue
                out.append(dict(page=pn, y=y, name=name, price=v[0], dp=v[1], hp=v[2:5], mi=v[5:8]))
    return out

BRANDS = {'HAIER':'Haier','DAWLANCE':'Dawlance','PEL':'PEL','SUPER':'Super Asia','WESTPOINT':'Westpoint','WEST':'Westpoint','ROYAL':'Royal','TCL':'TCL','SAMSUNG':'Samsung','BOSS':'Boss','GREE':'Gree','NASGAS':'Nasgas','CAMBRIDGE':'Cambridge','COMBRIDGE':'Cambridge','HOMAGE':'Homage','HONDA':'Honda','KENWOOD':'Kenwood','SIGMA':'Sigma','PHILIPS':'Philips','CANNON':'Canon','CANON':'Canon','ECOSTAR':'EcoStar','ECO':'EcoStar','INFINIX':'Infinix','AUDIONIC':'Audionic','VIVO':'Vivo','UNITED':'United','REDMI':'Redmi','PANASONIC':'Panasonic','HYUNDAI':'Hyundai','HP':'HP','OPPO':'Oppo','TECNO':'Tecno','XIAOMI':'Xiaomi','ITEL':'Itel','REALME':'Realme','ORIENT':'Orient','GFC':'GFC','V-ON':'V-ON','INTAG':'Intag','NATIONAL':'National','SONY':'Sony','LG':'LG','DELL':'Dell','LENOVO':'Lenovo','ASUS':'Asus','ACER':'Acer'}
CATS = [
 ('Washing Machines', ['WASHING','W/MACHINE','SPIN DRYER','WASHER']),
 ('Refrigerators & Freezers', ['REFRIGERATOR','REF ','FREEZER','CHEST','VISI COOLER']),
 ('Air Conditioners', ['SPLIT AC',' AC ','AIR CONDITIONER','AC SPLIT','INVERTER AC','AC-']),
 ('LED TVs', ['LED','TV ','SMART TV','ANDROID TV','OLED']),
 ('Mobile Phones', ['MOBILE','SMART PHONE','SMARTPHONE','INFINIX','TECNO','VIVO','REDMI','OPPO','ITEL','REALME','GALAXY']),
 ('Laptops & Computers', ['LAPTOP','NOTEBOOK','DESKTOP','TABLET']),
 ('Vehicles & Motorcycles', ['MOTORCYCLE','M/CYCLE','MOTOR CYCLE','BIKE','SCOOTER','CARS','USED CAR']),
 ('Microwave & Ovens', ['MICROWAVE','MICRO WAVE','OVEN','AIR FRYER','TOASTER']),
 ('Fans & Coolers', ['FAN','COOLER','HEATER','GEYSER']),
 ('Solar & Power', ['SOLAR','UPS','BATTERY','GENERATOR']),
 ('Kitchen Appliances', ['BLENDER','JUICER','KETTLE','COOKER','HOB','HOOD','DISPENSER','CHOPPER','GRINDER','STOVE','FOOD']),
 ('Home Appliances', ['IRON','VACUUM','DRYER','WATER','PUMP','MOTOR']),
]

def clean(n): return re.sub(r'\s+', ' ', html.unescape(n)).strip()

def category(name):
    n = ' ' + name.upper() + ' '
    for cat, keys in CATS:
        if any(k in n for k in keys): return cat
    return 'Other Products'

def brand(name):
    toks = name.upper().split()
    if not toks: return 'Other'
    if toks[0] == 'SUPER' and len(toks) > 1 and toks[1] == 'ASIA': return 'Super Asia'
    return BRANDS.get(toks[0], 'Other')

def model(name):
    toks = [t for t in name.split() if re.search(r'[A-Za-z]', t) and re.search(r'\d', t) and len(t) >= 3]
    return toks[-1] if toks else ''

def resolve_name(names, n):
    # The advance-% digit of each row is sometimes printed over the model text.
    # Recover the clean name as the one candidate common to all rows.
    if len(set(names)) == 1:
        return names[0], (0 if n == 6 else 1)
    def cands(nm, ch):
        c = {nm}
        for i, x in enumerate(nm):
            if x == ch: c.add(nm[:i] + nm[i+1:])
        return c
    common = None
    for k, nm in enumerate(names):
        c = cands(nm, str(k))
        common = c if common is None else common & c
    if common:
        return max(common, key=len), (0 if n == 6 else 1)
    top = collections.Counter(names).most_common(1)[0]
    return (top[0] if top[1] > 1 else min(names, key=len)), 1

def main(pdf, out):
    rows = read_rows(pdf)
    rows.sort(key=lambda r: (r['page'], r['y']))
    blocks, cur = [], []
    for r in rows:
        if cur and r['price'] == cur[-1]['price'] and len(cur) < 6: cur.append(r)
        else:
            if cur: blocks.append(cur)
            cur = [r]
    if cur: blocks.append(cur)
    with open(out, 'w', encoding='utf-8') as f:
        for i, b in enumerate(blocks, 1):
            names = [clean(r['name']) for r in b]
            name, review = resolve_name(names, len(b))
            cols = [str(i), str(b[0]['page']), name.replace('\t', ' '), brand(name), model(name), category(name), str(review), str(b[0]['price'])]
            for k, r in enumerate(b):
                pct = k * 10 if len(b) == 6 else -1
                cols += [str(pct), str(r['dp'])] + [str(x) for x in r['hp']] + [str(x) for x in r['mi']]
            f.write('\t'.join(cols) + '\n')
    print(len(blocks), 'products written')

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
